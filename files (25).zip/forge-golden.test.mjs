// GOLDEN CONFORMANCE — the 9 quality-bar builds must compile+execute through the
// SHIPPED Forge pipeline (strategy S1 'whole'), exactly as model output would.
// Run: node forge-golden.test.mjs
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const FORGE = require('./forge-reference.js');
const GOLDEN = require('./thunder-golden-library.js');

// ── minimal THREE stub (builds only touch THREE.Group directly) ─────────────
class Vec3 { constructor(x=0,y=0,z=0){this.x=x;this.y=y;this.z=z;}
  set(x,y,z){this.x=x;this.y=y;this.z=z;return this;} copy(v){return this.set(v.x,v.y,v.z);}
  clone(){return new Vec3(this.x,this.y,this.z);} add(v){this.x+=v.x;this.y+=v.y;this.z+=v.z;return this;}
  sub(v){this.x-=v.x;this.y-=v.y;this.z-=v.z;return this;} multiplyScalar(s){this.x*=s;this.y*=s;this.z*=s;return this;}
  length(){return Math.hypot(this.x,this.y,this.z);} normalize(){const l=this.length()||1;return this.multiplyScalar(1/l);} }
class Obj3D { constructor(){this.children=[];this.position=new Vec3();this.rotation=new Vec3();
  this.scale=new Vec3(1,1,1);this.userData={};this.visible=true;this.quaternion={setFromUnitVectors(){}};}
  add(...o){o.forEach(c=>this.children.push(c));return this;} }
class Group extends Obj3D {}
class Mesh extends Obj3D { constructor(){super();this.isMesh=true;} }
const THREE = { Group, Vector3: Vec3 };

// ── VG v1.1 stub — full surface, structure-faithful mesh counts ─────────────
const mesh = () => new Mesh();
const groupOf = (n) => { const g=new Group(); for(let i=0;i<n;i++) g.add(mesh()); return g; };
const mat = () => ({});
const VG = {
  C: new Proxy({}, { get: () => 0xabcdef }),                    // palette: any name resolves
  paint:mat, matte:mat, metalMat:mat, goldMat:mat, emiss:mat, makeGlass:mat, GLASS_BLUE:mat,
  box:mesh, cyl:mesh, cone:mesh, sphere:mesh, ico:mesh, torus:mesh,
  eye:()=>groupOf(2),
  glow:()=>new Obj3D(),                                          // sprite: not a mesh
  jaggedBolt:(len,segs)=>{ const g=groupOf(segs||5); g.add(new Obj3D());
    g.userData.strike=()=>{}; g.userData.phase=0; g.userData.period=1; g.userData.duty=0.2; return g; },
  knobbyWheel:()=>groupOf(10),                                   // tire + 8 knobs + hub
  slickWheel:()=>groupOf(2),                                     // tire + hub
  decalPlane:mesh, boltDecal:mesh, numDecal:mesh, runeDecal:mesh, tomoeDecal:mesh, greekKey:mesh,
  contactShadow:mesh,
  figure:(skin,torsoM,o)=>{ const g=groupOf(2);                  // torso + head
    g.userData.head=g.children[1];
    const armL=groupOf(2), armR=groupOf(2); g.add(armL,armR);    // up+hand each
    g.userData.armL=armL; g.userData.armR=armR; return g; },
  tickBolts:()=>{},
};

// ── expected baselines (frozen after first green run; drift = regression) ───
const EXPECTED = {
  thor: 106, zeus: 57, raijin: 72, tlaloc: 100, perun: 59,
  shango: 94, indra: 84, leigong: 51, thunderbird: 99,
};

let pass = 0, total = 0;
const rows = [];
for (const id of Object.keys(GOLDEN.LIBRARY)) {
  total++;
  const entry = GOLDEN.LIBRARY[id];
  const r = FORGE.compile(entry.code, { THREE, VG, maxMeshes: 220 });
  if (!r.ok) { rows.push([id, 'FAIL: ' + (r.attempts?.[0]?.err || r.err), '✗']); continue; }
  const tickOk = typeof r.group.userData.tick === 'function';
  const via = r.strategy;
  const exp = EXPECTED[id];
  const countOk = exp == null || r.cert.meshes === exp;
  const ok = via === 'whole' && tickOk && countOk;
  if (ok) pass++;
  rows.push([id, `via ${via} · ${r.cert.meshes} meshes · tick:${tickOk?'yes':'NO'}` +
    (exp !== undefined && !countOk ? ` · EXPECTED ${exp}` : ''), ok ? '✓' : '✗']);
}
console.log('\nGOLDEN CONFORMANCE — 9 quality-bar builds through the shipped Forge\n' + '─'.repeat(78));
for (const [id, msg, v] of rows) console.log(id.padEnd(13), '|', msg.padEnd(52), '|', v);
console.log('─'.repeat(78));
console.log(`golden: ${pass}/${total} via S1 'whole' with live tick contract`);

// keyword pick() sanity — a few realistic prompts route to sensible goldens
const PICKS = [
  ['a viking monster truck with a hammer', 'thor'],
  ['red oni demon with taiko drums', 'raijin'],
  ['an elephant hauler from india', 'indra'],
  ['giant bird totem with feathers', 'thunderbird'],
];
let pickPass = 0;
for (const [prompt, want] of PICKS) {
  const got = GOLDEN.pick(prompt).id;
  const ok = got === want; if (ok) pickPass++;
  console.log(`pick(${JSON.stringify(prompt)}) → ${got} ${ok ? '✓' : '✗ want ' + want}`);
}
if (pass !== total || pickPass !== PICKS.length) process.exit(1);
console.log('\nGOLDEN GATE HOLDS.');
